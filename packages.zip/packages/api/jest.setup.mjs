// Global test setup
import { config } from 'dotenv';

// Load test environment variables
config({ path: '.env.test' });
